// Variable Declaration
var express = require("express");
const { render } = require("ejs");
var app = express();
var bodyParser = require("body-parser");
var mongoose = require("mongoose");
var passport = require("passport");
var localStrategy = require("passport-local");
var methodOverride = require("method-override");
var User = require("./models/user");
var seedDb = require("./seeds");
// const { ReplSet } = require("mongodb");
const dbUrl = process.env.DB_URL;

var commentRoutes = require("./routes/comments");
var shoppingRoutes = require("./routes/shoppings");
var indexRoutes = require("./routes/index");

app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");
// app.use(express.static("public"));
app.use(express.static(__dirname + '/public'));
app.use(methodOverride("_method"));
seedDb(); // seed the db

// PASSPORT CONFIGURTION
app.use(require("express-session")({
    secret: "Once a legend. Always a legend",
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
passport.use(new localStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(function(req, res, next){
    res.locals.currentUser = req.user;
    next();
});
//"mongodb://localhost:27017/lealcamp"
mongoose.connect(dbUrl,
    {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
        useFindAndModify: false

    }
);

app.use("/", indexRoutes);
app.use("/shoppings", shoppingRoutes);
app.use("/shoppings/:id/comments", commentRoutes);





app.listen(3000, function (req, res) {
    console.log("The Lealkart Server is started");
});