var mongoose = require("mongoose");
var Shopping = require("./models/shopping");
var Comment = require("./models/comment");

data = [
  {
    name: "MIND – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2020/11/Mind_B_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry."

  },
  {
    name: "Little Things – White",
    image:
    "https://www.weink.studio/wp-content/uploads/2020/10/Little-things_W_4.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  
  },
  {
    name: "jocker -black",
    image:
      "https://www.weink.studio/wp-content/uploads/2020/10/Joker_B_4.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Ctrl Alt Tab – White",
    image:
      "https://www.weink.studio/wp-content/uploads/2020/10/Ctrl-Alt-Del_W_4.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Helvetica – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2020/09/Helvetica_B_4.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Half – White",
    image:
      "https://www.weink.studio/wp-content/uploads/2020/09/Half_W_4.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Hi – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2020/11/Hi._B_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Angled Triangles – White",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/01/Broken-Triangle_W_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Be More – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/02/Be-More_B_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Binary – White",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/01/Binary_W_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Boundaries – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2020/11/Boundaries_B_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Be More – White",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/02/Be-More_W_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "CALM – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/02/Calm_B_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Canvas – White",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/02/Canvas_W_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Canvas – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/02/Canvas-new_B_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Curiosity – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/01/Curiosity-new_B_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Curiosity – White",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/01/Curiosity_W_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  },
  {
    name: "Extremity – Black",
    image:
      "https://www.weink.studio/wp-content/uploads/2021/01/Extremity_B_1.png",
    description:
      "Mineral is an elegant recombination of predominantly natural fabrics with a western construct, creating clothing that makes a woman look and feel special.Versatile, elegant, perfect fits and effortless styling are words which describe Mineral.Mineral believes that its collection transcends seasons and hence its motto of ‘no more seasons’.Mineral envisions itself to be recognized for simply great clothes that you want to live within, every day of your life.Mineral clothes can be styled up or down, transmuting from chic to casual without much effort.Mineral collections currently include clothing, handbags, fashion jewelry.",
  }
];

function seedDB() {
  // REMOVE ALL CAMPGROUNDS
  Shopping.remove({}, function (err) {
    if (err) {
      console.log(err);
    } else {
      console.log("shoppings removed");
    }

    data.forEach(function (seed) {
      Shopping.create(seed, function (err, shopping) {
        if (err) {
          console.log(err);
        } else {
          console.log("added a shopping");
          Comment.create(
            {
              text: "the quality of this t-shirt looks great. I'll suggest to my friends",
              author: "anudeep",
            },
            function (err, comment) {
              if (err) {
                console.log(err);
              } else {
                shopping.comments.push(comment);
                shopping.save();
                console.log("created new comment");
              }
            }
          );
        }
      });
    });
  });

  //ADD FEW CAMPGROUNS
}
// ADD FEW COMMENTS

module.exports = seedDB;
