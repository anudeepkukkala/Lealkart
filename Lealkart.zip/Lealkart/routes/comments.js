var express = require("express");
var router = express.Router({mergeParams: true});
var Shopping = require("../models/shopping");
var Comment = require("../models/comment");

// COMMENT ROUTES
router.get("/new",isLoggedIn , function (req, res) {
    // find campground by id
    Shopping.findById(req.params.id, function (err, shopping) {
        if (err) {
            console.log(err);
        } else {
            res.render("./comments/new", { shopping: shopping });
        }
    });
});

router.post("/",isLoggedIn, function (req, res) {
    Shopping.findById(req.params.id, function (err, shopping) {
        if (err) {
            console.log(err);
        } else {
            Comment.create(req.body.comment, function (err, comment) {
                if (err) {
                    console.log(err);
                } else {
                    // add the user name and id to comment
                    comment.author.id =  req.user._id;
                    comment.author.username = req.user.username;
                    // save comment
                    comment.save();
                    shopping.comments.push(comment);
                    shopping.save();
                    res.redirect("/shoppings/" + shopping._id);
                }
            });
        }
    });
});

// middleware
function isLoggedIn(req, res, next){
    if(req.isAuthenticated()){
       return next();
    }
    res.redirect("/login");
}

module.exports = router;