var express = require("express");
var router = express.Router();
var Shopping = require("../models/shopping");

//INDEX ROUTE - DISPLAY ALL ROUTES
router.get("/", function (req, res) {
    Shopping.find({}, function (err, allShoppings) {
        if (err) {
            console.log(err);
        } else {
            res.render("./shoppings/index", { shoppings: allShoppings});
        }
    });


});

// CREATE ROUTE - CREATE A NEW CAMPGROUNDS
router.post("/",isLoggedIn, function (req, res) {
    // get data from the form and add to the campgrounds array
    var name = req.body.name;
    var image = req.body.image;
    var desc = req.body.description;
    var author = {
        id: req.user._id,
        username: req.user.username
    }
    var newShopping = { name: name, image: image, description: desc , author: author};
    Shopping.create(newShopping, function (err, newlyAdded) {
        if (err) {
            console.log(err);
        } else {
            console.log(newlyAdded);
        }
    });
    // redirect to campgrounds page
    res.redirect("/shoppings");
});

// NEW ROUTE - SHOW FORM TO CREATE A NEW CAMPGROUND
router.get("/new" ,isLoggedIn ,function (req, res) {
    res.render("./shoppings/new");
});

// SHOW ROUTE - SHOW INFO ON ONE CAMPGROUND
router.get("/:id", function (req, res) {
    Shopping.findById(req.params.id).populate("comments").exec(function (err, foundShopping) {
        if (err) {
            console.log(err);
        } else {
            console.log(foundShopping);
            res.render("./shoppings/show", { shopping: foundShopping });
        }
    });
});

// EDIT ROUTE
router.get("/:id/edit", function(req, res){
    Shopping.findById(req.params.id, function(err, foundShopping){
       if(err){
           res.redirect("/shoppings");
       }  else {
        res.render("./shoppings/edit", {shopping: foundShopping});

       }
    });
});

// UPDATE ROUTE
router.put("/:id", function(req, res){
//   find and update the correct campground 
Shopping.findByIdAndUpdate(req.params.id, req.body.shopping, function(err, updatedShopping){
    if(err){
        res.redirect("/shoppings");
    } else {
        res.redirect("/shoppings/" + req.params.id);
    }
});
// redirect to the show page
});

// DESTROY CAMPGROUND ROUTE
router.delete("/:id", function(req, res){
    Shopping.findByIdAndRemove(req.params.id, function(err){
        if(err){  
           res.redirect("/shoppings"); 
        } else {
            res.redirect("/shoppings");
        }
    });
});

function isLoggedIn(req, res, next){
    if(req.isAuthenticated()){
       return next();
    }
    res.redirect("/login");
}

module.exports = router;